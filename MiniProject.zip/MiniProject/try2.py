from flask import Flask, request, render_template,session,redirect,flash
import time
from flask_session import Session
import psycopg2
import hidden
import os
import imdb


app = Flask(__name__)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)


def res(url):
        base, ext = os.path.splitext(url)
        i = url.count('@')
        s2 = url.split('@')[0]
        url = s2 + '@' * i + ext
        print(url)
        return url
class find:
    def __init__(self,M,N,ts,g,y1,y2,w=0):
        self.ia = imdb.IMDb()
        self.ts1=time.time()
        self.movies=[]
        self.mName=[]
        self.poster=[]
        self.plot=[]
        self.director=[]
        self.country=[]
        self.bo=[]
        self.company=[]
        self.genre=[]
        self.Rdate=[]
        self.IDs=[]
        self.n=0
        for i in M:
            
            if w==0:
                self.I=i
                if i.data['kind']!='movie':
                    continue
                self.Movie=i.movieID
                self.MName=self.ia.get_movie(self.Movie)
                print("ID types are :",type(self.Movie)," and ID is",self.Movie)

            elif w==1:
                self.Movie=i
                self.MName=self.ia.get_movie(self.Movie)
                self.I=self.MName



            try:
                if g!='Genres' and g not in self.MName.data['genres']:
                    continue

            except:
                continue

            try:
                if y1!='Years' and (y1>self.MName.data['year'] or y2<self.MName.data['year']):
                    continue

            except:
                continue

            if N<=16 and self.n<N:
                self.n=self.n+1
            else:
                break

            self.movies.append(self.Movie)
            self.mName.append(str(self.I))
            
            try:
                self.url=self.MName['cover url']
                print(self.url)
                self.poster.append(res(self.url))
            except:
                self.poster.append("-")

            try:    
                self.plot.append((self.MName['plot'])[0])
            except:
                self.plot.append("-")

            try:
                self.director.append(str(self.MName['director'])[str(self.MName['director']).find(':_')+2:str(self.MName['director']).find('_>')])
            except:
                self.director.append("-")
                
            try:
                self.country.append(str((self.MName['country'])[0]))
            except:
                self.country.append('-')

            self.date=self.ia.get_movie_release_dates(self.Movie)
            
            self.IDs.append(str(self.Movie))
            
            try:
                self.bo.append(((self.MName['box office'])["Cumulative Worldwide Gross"])[0:(self.MName['box office'])["Cumulative Worldwide Gross"].find(', ')])
            except:
                self.bo.append('-')

            try:    
                self.company.append(', '.join(map(str, self.MName['production companies'])))
            except:
                self.company.append('-')

            try:
                self.genre.append(', '.join(map(str, self.MName['genre'])))
            except:
                self.genre.append('-')

            for relEntry in self.date['data']['release dates']:
                if "USA" in relEntry:
                    self.Rdate.append(relEntry[4:relEntry.find('(')])
                    break
            ts1=time.time()
            print('In loop :',ts1-ts,' at ',i)

        self.N=len(self.movies)

ts=time.time()
ia = imdb.IMDb()            
secrets = hidden.secrets()
N=8
top250 = ia.get_top250_movies()
top=find(top250,N,ts,"Genres","Years","Years")

genres=['Drama','Crime','Action','Thriller','Biography','History','Adventure','Fantasy','Western','Romance','Sci-Fi','Mystery','Comedy','War','Family','Animation','Music','Horror','Musical','Film-Noir','Sport','Genres']

def w_db(ID,status):
    if status=='Like':
        fav=bool(1)
        status='watched'
    else:
        fav=bool(0)
    conn = psycopg2.connect(host=secrets['host'],
        port=secrets['port'],
        database=secrets['database'], 
        user=secrets['user'], 
        password=secrets['pass'], 
        connect_timeout=3)
    cur = conn.cursor()
    sql="Select status from watchlists where m_id=%s and u_id=%s;"
    cur.execute(sql,(ID,session.get("u_id"),))
    row=cur.fetchone()
    cur.close()
    print("ROW ROW:",row,"Type ROW:",type(row))
    if row is None:
        cur = conn.cursor()
        sql="Insert into watchlists(m_id,u_id,status,fav) values(%s,%s,%s,%s);"
        cur.execute(sql,(ID,session.get("u_id"),status,fav,))
        conn.commit()
        print("Done sir")
        cur.close()
    elif str((list(row))[0])=='watched' and fav==bool(1):
        cur = conn.cursor()
        sql="Update watchlists Set fav='t' where m_id=%s and u_id=%s ;"
        cur.execute(sql,(ID,session.get("u_id"),))
        conn.commit()

    elif str((list(row))[0])=='not watched' and fav==bool(0) and status=='watched':
        cur = conn.cursor()
        sql="Update watchlists Set status='watched' where m_id=%s and u_id=%s ;"
        cur.execute(sql,(ID,session.get("u_id"),))
        conn.commit()

    elif str((list(row))[0])=='not watched' and fav==bool(1) and status=='watched':
        cur = conn.cursor()
        sql="Update watchlists Set status='watched', fav='t' where m_id=%s and u_id=%s ;"
        cur.execute(sql,(ID,session.get("u_id"),))
        conn.commit()

    elif status=='Remove':
        cur = conn.cursor()
        sql="Delete from watchlists where m_id=%s and u_id=%s ;"
        cur.execute(sql,(ID,session.get("u_id"),))
        conn.commit()

    else:

        print((list(row))[0])
    
    conn.close()
    return ('', 204)





@app.route("/", methods=["POST", "GET"])
@app.route('/index', methods =["GET", "POST"])
def hello():
    print(session.get("u_id"))
    if session.get("u_id"):
        hidden1='hidden'
        hidden2=''
        print('hidden1=',hidden1)
        print('hidden2=',hidden2)
    else:
        hidden2='hidden'
        hidden1=''
        print('hidden1=',hidden1)
        print('hidden2=',hidden2)
    
    
    ts=time.time()
    ts1=time.time()
    print('Start :',ts1-ts)
    
            
    if request.method == "POST":
        try:
            if request.form["search"] is not None:
                N=4
                M= request.form.get("search")
                G= request.form.get("Genres")
                Y= request.form.get("Years")
                Y1=Y
                Y2=Y
                if Y != 'Years':
                    Y1=int(Y[0:4])
                    Y2=int(Y[5:9])
                print('Movie: ',M,' Genre: ',G,' Year: ',Y1,' to ',Y2)
                if M=='':
                    if G!= 'Genre':
                        M=top250
                    if Y1==2021:
                        M=ia.get_popular100_movies()
                else:
                    M = ia.search_movie(M)
                print(' type ',type(M),'First ',M[0])
                M=find(M,N,ts,G,Y1,Y2)
        except:
            print("Not Now")
        try:
            if request.form["Like"] is not None:
                ID=request.form["Like"]
                w_db(ID,'Like')
                return ('', 204)

        except Exception as e:
            print("Exception is:",e)
            
        try:
            if request.form["watched"] is not None:
                ID=request.form["watched"]
                w_db(ID,'watched')
                return ('', 204)

        except Exception as e:
            print("Exception is:",e)
            
        try:
            if request.form["ADD"] is not None:
                ID=request.form["ADD"]
                w_db(ID,'not watched')
                return ('', 204)

        except Exception as e:
            print("Exception is:",e)
            


    else:    
        M=top
        ts1=time.time()
        print('Top 250 :',ts1-ts,' and type ',type(M))
    
    try:
        mName=M.mName
        poster=M.poster
        plot=M.plot
        Rdate=M.Rdate
        director=M.director
        country=M.country
        bo=M.bo
        company=M.company
        genre=M.genre
        IDs=M.IDs
        N=M.N
        print(mName)
        return render_template("index3.html",url=poster,mName=mName,plot=plot,date=Rdate,director=director,country=country,bo=bo,company=company,genre=genre,IDs=IDs,N=N,hidden1=hidden1,hidden2=hidden2,genres=genres)
    except Exception as e:
        print("Exception is:",e)
        return ('', 204)

@app.route('/watchlist', methods =["GET", "POST"])
def watchlist():
    if request.method == "POST":
        try:
            if request.form["Like"] is not None:
                ID=request.form["Like"]
                w_db(ID,'Like')
                

        except Exception as e:
            print("Exception is:",e)
            
        try:
            if request.form["watched"] is not None:
                ID=request.form["watched"]
                w_db(ID,'watched')

        except Exception as e:
            print("Exception is:",e)

        try:
            if request.form["Remove"] is not None:
                ID=request.form["Remove"]
                w_db(ID,'Remove')

        except Exception as e:
            print("Exception is:",e)

    conn = psycopg2.connect(host=secrets['host'],
        port=secrets['port'],
        database=secrets['database'], 
        user=secrets['user'], 
        password=secrets['pass'], 
        connect_timeout=3)
    cur = conn.cursor()
    sql="Select m_id from watchlists where u_id=%s and status='not watched';"
    cur.execute(sql,(session.get("u_id"),))
    WL=[item[0] for item in cur.fetchall()]
    cur.close()
    cur = conn.cursor()
    sql="Select m_id from watchlists where u_id=%s and fav='t'order by updated_at desc;"
    cur.execute(sql,(session.get("u_id"),))
    L=[item[0] for item in cur.fetchall()]
    cur.close()
    cur = conn.cursor()
    sql="Select m_id from watchlists where u_id=%s and fav='f' and status='watched';"
    cur.execute(sql,(session.get("u_id"),))
    W=[item[0] for item in cur.fetchall()]
    cur.close()
    conn.close()
    print("these are rows please watch:",L)
    N=9
    NWL=len(WL)
    if NWL>3:
        NWL=3
        WL=WL[0:3]
    NL=len(L)+NWL
    if NWL==0 and len(L)>=3:
        NL=3
        L=L[0:3]
    
    if NL>6:
        NL=NWL+3
        L=L[0:3]
    NW=len(W)+NL
    if NL==0:
        if NWL==0:
            NW=3
        else:
            NW=6
    if NW>9:
        NW=NL+3
        W=W[0:3]
    print("NWL:",NWL,'NL: ',NL)
    print("NW",NW)
    M=WL+L+W
    M=find(M,NW,ts,"Genres","Years","Years",1)
    mName=M.mName
    poster=M.poster
    N=M.N
    IDs=M.IDs


    print(mName)
    return render_template("watchlist2.html",url=poster,mName=mName,NWL=NWL,NL=NL,NW=NW,IDs=IDs)
    

@app.route("/quiz", methods=['GET', 'POST'])
def quiz():
    answer = request.args.get('answer')
    conn = psycopg2.connect(host=secrets['host'],
    port=secrets['port'],
    database=secrets['database'], 
    user=secrets['user'], 
    password=secrets['pass'], 
    connect_timeout=3)
    cur = conn.cursor()
    sql="Select q_id from answers where u_id=%s;"
    cur.execute(sql,(session.get("u_id"),))
    try:
        row = list(cur.fetchone())
    except:
        row=cur.fetchone()
    if row is not None:
        sql="Insert into answers(answer,u_id,q_id) values(%s,%s,%s)"
        print("row is",row[0])
        cur.execute(sql,(answer,session.get("u_id"),row[0],))
        conn.commit()

    else:
        sql="Insert Into quizs(completed_at) values('2021-10-04 17:19:04.996798+05:30');"
        cur.execute(sql,)
        conn.commit()
        sql="Select qid from quizs order by qid DESC;"
        cur.execute(sql,)
        row = cur.fetchone()
        sql="Insert into answers(answer,u_id,q_id) values(%s,%s,%s)"
        print("row is",row[0])
        cur.execute(sql,(answer,session.get("u_id"),row[0],))
        conn.commit()


    cur.close()
    conn.close()

    print("answer is ",answer)
    return ('', 204)



@app.route("/login", methods=["POST", "GET"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password=request.form.get("password")
        conn = psycopg2.connect(host=secrets['host'],
        port=secrets['port'],
        database=secrets['database'], 
        user=secrets['user'], 
        password=secrets['pass'], 
        connect_timeout=3)
        cur = conn.cursor()
        sql="Select id from users where u_name=%s and password=%s;"
        cur.execute(sql,(username,password,))
        row = cur.fetchone()
        print(username,' ',password,' ',type(username),' ',row,' ',type(row))
        cur.close()
        conn.close()
        if row is not None:
            session["u_id"] = row
            return redirect("/index")
        else:
            print(row)
            flash(u'Invalid password or username', 'error')
            
    return render_template("login.html")

@app.route("/signup", methods=["POST", "GET"])
def signup():
    if request.method == "POST":
        username = request.form.get("username")
        password1=request.form.get("password")
        password2 = request.form.get("password2")
        mail = request.form.get("mail")
        dob = request.form.get("dob")
        conn = psycopg2.connect(host=secrets['host'],
        port=secrets['port'],
        database=secrets['database'], 
        user=secrets['user'], 
        password=secrets['pass'], 
        connect_timeout=3)
        cur = conn.cursor()
        sql="Select id from users where u_name=%s or mail=%s;"
        cur.execute(sql,(username,mail,))
        row = cur.fetchone()
        cur.close()
        print(row,' ',type(row),' type of dob',type(dob))

         
        if row is None:
            if password1==password2:

                l, u, p, d = 0, 0, 0, 0
                for i in password1:

                    if (i.islower()):
                        l+=1            

                    if (i.isupper()):
                        u+=1            

                    if (i.isdigit()):
                        d+=1            

                    if(i=='@'or i=='$' or i=='_'):
                        p+=1           
        
                if (l>=1 and u>=1 and p>=1 and d>=1 and len(password1) >= 8 and l+p+u+d==len(password1)):

                    cur = conn.cursor()
                    sql="Insert into users(u_name,password,dob,mail) values(%s,%s,%s,%s);"
                    cur.execute(sql,(username,password1,dob,mail,))
                    conn.commit()
                    sql="Select id from users where u_name=%s and password=%s;"
                    cur.execute(sql,(username,password1,))
                    row = cur.fetchone()
                    cur.close()
                    conn.close()
                    session["u_id"] = row
                    return redirect("/index")

                else:
                    flash(u'Passwords is not strong', 'error')
            

            else:
                flash(u'Passwords did not match', 'error')
        else:
            cur = conn.cursor()
            sql="Select id from users where u_name=%s"
            cur.execute(sql,(username,))
            u_name=cur.fetchone()
            cur.close()

            cur = conn.cursor()
            sql="Select id from users where mail=%s"
            cur.execute(sql,(mail,))
            u_mail=cur.fetchone()
            cur.close()

            if u_name is not None:
                flash(u'username already in Use', 'error')

            if u_mail is not None:
                flash(u'Mail already in Use', 'error')

            conn.close()
            
    return render_template("signup.html")

@app.route("/logout")
def logout():
    session.pop("u_id", None)
    return redirect("/index")
 
@app.route("/about")
def about():
    return render_template("about.html")

if __name__=='__main__':
    app.run(debug=True)
