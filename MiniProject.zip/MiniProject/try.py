from flask import Flask, request, render_template,session,redirect
import imdb
import time
from flask_session import Session
import psycopg2
import hidden
import os


app = Flask(__name__)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)


def res(url):
        base, ext = os.path.splitext(url)
        i = url.count('@')
        s2 = url.split('@')[0]
        url = s2 + '@' * i + ext
        print(url)
        return url
class find:
    def __init__(self,M,N,ts,g,y1,y2):
        self.ia = imdb.IMDb()
        self.ts1=time.time()
        self.movies=[]
        self.mName=[]
        self.poster=[]
        self.plot=[]
        self.director=[]
        self.country=[]
        self.bo=[]
        self.company=[]
        self.genre=[]
        self.Rdate=[]
        self.IDs=[]
        self.n=0
        for i in M:

            if i.data['kind']!='movie':
                continue

            self.Movie=i.movieID
            self.MName=self.ia.get_movie(self.Movie)

            try:
                    if g!='Genres' and g not in self.MName.data['genres']:
                        continue

            except:
                    continue

            try:
                    if y1!='Years' and (y1>self.MName.data['year'] or y2<self.MName.data['year']):
                        continue

            except:
                    continue

            if N<=16 and self.n<N:
                self.n=self.n+1
            else:
                break

            self.movies.append(i.movieID)
            self.mName.append(str(i))
            
            try:
                self.url=self.MName['cover url']
                print(self.url)
                self.poster.append(res(self.url))
            except:
                self.poster.append("-")

            try:    
                self.plot.append((self.MName['plot'])[0])
            except:
                self.plot.append("-")

            try:
                self.director.append(str(self.MName['director'])[str(self.MName['director']).find(':_')+2:str(self.MName['director']).find('_>')])
            except:
                self.director.append("-")
                
            try:
                self.country.append(str((self.MName['country'])[0]))
            except:
                self.country.append('-')

            self.date=self.ia.get_movie_release_dates(self.Movie)
            
            self.IDs.append(str(self.Movie))
            
            try:
                self.bo.append(((self.MName['box office'])["Cumulative Worldwide Gross"])[0:(self.MName['box office'])["Cumulative Worldwide Gross"].find(', ')])
            except:
                self.bo.append('-')

            try:    
                self.company.append(', '.join(map(str, self.MName['production companies'])))
            except:
                self.company.append('-')

            try:
                self.genre.append(', '.join(map(str, self.MName['genre'])))
            except:
                self.genre.append('-')

            for relEntry in self.date['data']['release dates']:
                if "USA" in relEntry:
                    self.Rdate.append(relEntry[4:relEntry.find('(')])
                    break
            ts1=time.time()
            print('In loop :',ts1-ts,' at ',i)

        self.N=len(self.movies)

ts=time.time()
ia = imdb.IMDb()            
secrets = hidden.secrets()
N=1
top250 = ia.get_top250_movies()
top=find(top250,N,ts,"Genres","Years","Years")

genres=['Drama','Crime','Action','Thriller','Biography','History','Adventure','Fantasy','Western','Romance','Sci-Fi','Mystery','Comedy','War','Family','Animation','Music','Horror','Musical','Film-Noir','Sport']

@app.route("/", methods=["POST", "GET"])
@app.route('/index', methods =["GET", "POST"])
def hello():
    print(session.get("name"))
    if session.get("name"):
        hidden1='hidden'
        hidden2=''
        print('hidden1=',hidden1)
        print('hidden2=',hidden2)
    else:
        hidden2='hidden'
        hidden1=''
        print('hidden1=',hidden1)
        print('hidden2=',hidden2)
    
    
    ts=time.time()
    ts1=time.time()
    print('Start :',ts1-ts)
    
    if request.method == "POST":
        N=4
        M= request.form.get("search")
        G= request.form.get("Genres")
        Y= request.form.get("Years")
        Y1=Y
        Y2=Y
        if Y != 'Years':
                Y1=int(Y[0:4])
                Y2=int(Y[5:9])
        print('Movie: ',M,' Genre: ',G,' Year: ',Y1,' to ',Y2)
        if M=='':
                if G!= 'Genre':
                        M=top250
                if Y1==2021:
                        M=ia.get_popular100_movies()
        else:
                M = ia.search_movie(M)
        print(' type ',type(M),'First ',M[0])
        M=find(M,N,ts,G,Y1,Y2)
        

    else:    
        M=top
        ts1=time.time()
        print('Top 250 :',ts1-ts,' and type ',type(M))
    
    
    mName=M.mName
    poster=M.poster
    plot=M.plot
    Rdate=M.Rdate
    director=M.director
    country=M.country
    bo=M.bo
    company=M.company
    genre=M.genre
    IDs=M.IDs
    N=M.N
    print(mName)
    return render_template("index3.html",url=poster,mName=mName,plot=plot,date=Rdate,director=director,country=country,bo=bo,company=company,genre=genre,IDs=IDs,N=N,hidden1=hidden1,hidden2=hidden2,genres=genres)


@app.route("/login", methods=["POST", "GET"])
def login():
    if request.method == "POST":
        username = request.form.get("name")
        password=request.form.get("password")
        conn = psycopg2.connect(host=secrets['host'],
        port=secrets['port'],
        database=secrets['database'], 
        user=secrets['user'], 
        password=secrets['pass'], 
        connect_timeout=3)
        cur = conn.cursor()
        sql="Select id from users where u_name=%s and password=%s;"
        cur.execute(sql,(username,password,))
        row = cur.fetchone()
        print(username,' ',password,' ',type(username),' ',row,' ',type(row))
        if row is not None:
            session["name"] = row
            print(session["name"])
            print(session.get("name"))
            return redirect("/index")
        else:
            print(row)
            return render_template("login.html")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.pop("name", None)
    return redirect("/index")
        
if __name__=='__main__':
    app.run(debug=True)
