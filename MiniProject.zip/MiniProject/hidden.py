def secrets():
    return {"host": "localhost",
            "port": 5432,
            "database": "postgres",
            "user": "postgres",
            "pass": "12345678"}
